create PROCEDURE get_triggers_print_format(rc IN SYS_REFCURSOR) AS
    names VARCHAR2(20);
    triggers VARCHAR2(20);
    BEGIN
        IF rc%ROWCOUNT=0 THEN
            DBMS_OUTPUT.PUT_LINE('triggers for requested table and schema combination are did not exists');
        ELSE
            LOOP
                FETCH rc INTO names, triggers;
                EXIT WHEN rc%NOTFOUND;
                DBMS_OUTPUT.PUT_LINE(names || ' | ' || triggers);
            END LOOP;
        END IF;
    END;
/

