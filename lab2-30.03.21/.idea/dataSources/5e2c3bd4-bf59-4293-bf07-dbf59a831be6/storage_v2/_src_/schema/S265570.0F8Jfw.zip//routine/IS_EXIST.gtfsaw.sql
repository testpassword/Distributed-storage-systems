create FUNCTION is_exist(where_ IN VARCHAR2, what_ IN VARCHAR2, field_ IN VARCHAR2) RETURN BOOLEAN AS
    accepted_results NUMBER;
BEGIN
    EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || where_ ||
                      ' WHERE ' || field_ || q'[ = ']' || what_ || q'[']'
        INTO accepted_results;
    IF accepted_results = 0 THEN RETURN FALSE;
    ELSE RETURN TRUE;
    END IF;
END;
/

