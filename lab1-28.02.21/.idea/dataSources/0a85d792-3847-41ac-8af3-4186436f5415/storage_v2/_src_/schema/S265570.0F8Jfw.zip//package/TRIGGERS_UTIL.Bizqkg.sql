create PACKAGE triggers_util AS
    PROCEDURE get_filtered(tbl_name IN VARCHAR2, scheme_name IN VARCHAR2, trg_cursor OUT SYS_REFCURSOR);
    PROCEDURE print_format(rc IN SYS_REFCURSOR);
END;
/

