create PACKAGE BODY triggers_util AS
    -- получить курсор с именами колонок и назначенных на них триггеров для запрошенного сочетания таблицы и схемы
    PROCEDURE get_filtered(tbl_name IN VARCHAR2, scheme_name IN VARCHAR2, trg_cursor OUT SYS_REFCURSOR) AS
    BEGIN
        OPEN trg_cursor FOR
            SELECT column_name, trigger_name FROM dba_trigger_cols
            WHERE table_name LIKE tbl_name AND
                  trigger_owner LIKE scheme_name AND
                  table_owner LIKE scheme_name;
    END;

    -- вывести курсор с колонками и триггерами
    PROCEDURE print_format(rc IN SYS_REFCURSOR) AS
        names VARCHAR2(32);
        triggers VARCHAR2(32);
        BEGIN
            DBMS_OUTPUT.PUT_LINE(RPAD('COLUMN NAME', 23) || ' ' || RPAD('TRIGGER NAME', 23));
            DBMS_OUTPUT.PUT_LINE(RPAD('-', 23, '-') || ' ' || RPAD('-', 23, '-'));
            FETCH rc INTO names, triggers;
            IF rc%FOUND THEN
                LOOP
                    FETCH rc INTO names, triggers;
                    EXIT WHEN rc%NOTFOUND;
                    DBMS_OUTPUT.PUT_LINE(RPAD(names, 23) || ' ' || RPAD(triggers, 23));
                END LOOP;
            ELSE DBMS_OUTPUT.PUT_LINE('triggers for requested table and schema combination are did not exists');
            END IF;
        END;
END;
/

