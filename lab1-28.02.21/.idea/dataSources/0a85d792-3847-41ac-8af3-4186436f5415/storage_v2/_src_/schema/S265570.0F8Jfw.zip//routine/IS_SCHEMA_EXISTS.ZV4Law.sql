create FUNCTION is_schema_exists(schema_name IN VARCHAR2) RETURN BOOLEAN AS
        accepted_schemas_count NUMBER;
    BEGIN
        SELECT COUNT(*) INTO accepted_schemas_count FROM dba_users WHERE username = schema_name;
        IF accepted_schemas_count = 0 THEN RETURN FALSE;
        ELSE RETURN TRUE;
        END IF;
    END;
/

