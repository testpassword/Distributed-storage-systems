create PROCEDURE get_triggers(tbl_name IN VARCHAR2, scheme_name IN VARCHAR2, trg_cursor OUT SYS_REFCURSOR) AS
    BEGIN
        OPEN trg_cursor FOR
            SELECT column_name AS "COLUMN NAME",
                   trigger_name AS "TRIGGER NAME"
            FROM dba_trigger_cols
            WHERE table_name LIKE tbl_name AND
                  trigger_owner LIKE scheme_name AND
                  table_owner LIKE scheme_name;
    END;
/

