create PROCEDURE schema_is_exists(name VARCHAR2(32)) AS
    BEGIN

    END;

SET SERVEROUTPUT ON;
ACCEPT s CHAR PROMPT 'Type scheme name: '
SELECT username FROM sys.dba_users WHERE username LIKE s
--
--
-- DECLARE
--     result_cursor SYS_REFCURSOR;
--     table_name VARCHAR2(32) := 'fd';
--     scheme_name VARCHAR2(32) := 'ds';
-- BEGIN
--     triggers_util.get_filtered(table_name, scheme_name, result_cursor);
--     triggers_util.print_format(result_cursor);
-- END;
/

