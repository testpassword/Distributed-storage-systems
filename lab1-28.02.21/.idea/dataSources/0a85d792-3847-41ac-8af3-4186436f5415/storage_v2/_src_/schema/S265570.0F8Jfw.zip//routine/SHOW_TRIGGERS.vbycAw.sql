create PROCEDURE show_triggers(tbl_name IN VARCHAR2, scheme_name IN VARCHAR2) AS
    BEGIN
        SELECT column_name AS "COLUMN NAME", trigger_name AS "TRIGGER NAME" FROM dba_trigger_cols
        WHERE table_name LIKE tbl_name AND
              trigger_owner like scheme_name AND
              table_owner like scheme_name;
        -- если пусто, то вывести сообщение об этом
    END;
/

