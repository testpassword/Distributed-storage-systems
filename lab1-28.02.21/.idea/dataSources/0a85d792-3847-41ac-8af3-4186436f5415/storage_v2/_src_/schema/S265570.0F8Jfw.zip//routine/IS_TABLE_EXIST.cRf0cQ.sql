create FUNCTION is_table_exist(tbl IN VARCHAR2) RETURN BOOLEAN AS
    accepted_tables_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO accepted_tables_count FROM dba_tables WHERE table_name = tbl;
    IF accepted_tables_count = 0 THEN RETURN FALSE;
    ELSE RETURN TRUE;
    END IF;
END;
/

